let data;

function preload(){
  data = loadJSON("Food.json");
}

function setup() {
  createCanvas(500, 400);
}

function draw() {
  background(220);
  
  let HighCarbs1 = data.HighCarbs[0].name;
  let HighCarbscarbs = data.HighCarbs[0].carbs;
  let HighCarbssod1 = data.HighCarbs[0].sodium;
  let HighCarbs2 = data.HighCarbs[1].name;
  let HighCarbscarbs2 = data.HighCarbs[1].carbs;
  let HighCarbssod2 = data.HighCarbs[1].sodium;
  let HighCarbs3 = data.HighCarbs[2].name;
  let HighCarbscarbs3 = data.HighCarbs[2].carbs;
  let HighCarbssod3 = data.HighCarbs[2].sodium;
  let HighCarbs4 = data.HighCarbs[3].name;
  let HighCarbscarbs4 = data.HighCarbs[3].carbs;
  let HighCarbssod4 = data.HighCarbs[3].sodium;
  let HighCarbs5 = data.HighCarbs[4].name;
  let HighCarbscarbs5 = data.HighCarbs[4].carbs;
  let HighCarbssod5 = data.HighCarbs[4].sodium;
  
  //Title
  textSize(15);
  fill(255,0,0)
  text("Carbs", 200, 50)
  fill(0);
  text("&", 250, 50)
  fill(0,0,255)
  text("Sodium", 270, 50)
  
  //List object: Ramen 1
  fill(0);
  textSize(7.5);
  text(HighCarbs1, 5, 350);
  
  //Bar:Carbs, Ramen 1
  strokeWeight(1);
  fill(255,10,10)
  rect(50,300,20,HighCarbscarbs)
  
   //Bar:Sodium, Ramen 1
  strokeWeight(1);
  fill(0,0,255)
  rect(70,328,20,HighCarbssod1 * 10)
  
  //List object: SunChips 2
  fill(0);
  textSize(7.5);
  text(HighCarbs2, 160, 350);
  
  //Bar:Carbs, SChips 2
  strokeWeight(1);
  fill(255,10,10)
  rect(160,320,20,HighCarbscarbs2)
  
   //Bar:Sodium, SChips 2
  strokeWeight(1);
  fill(0,0,255)
  rect(181,338,20,HighCarbssod2 * 10)
  
  //List object: Cbury 3
  fill(0);
  textSize(7.5);
  text(HighCarbs3, 225, 352);
  
  //Bar:Carbs, Cbury 3
  strokeWeight(1);
  fill(255,10,10)
  rect(240, 320,20,HighCarbscarbs3)
  
   //Bar:Sodium, Cbury 3
  strokeWeight(1);
  fill(0,0,255)
  rect(261, 341.5,20,HighCarbssod3 * 10)
  
  //List object: RCRV 4
  fill(0);
  textSize(7.5);
  text(HighCarbs4, 305, 350);
  
  //Bar:Carbs, RCRV 4
  strokeWeight(1);
  fill(255,10,10)
  rect(340, 330,20,HighCarbscarbs4)
  
   //Bar:Sodium, RCRV 4
  strokeWeight(1);
  fill(0,0,255)
  rect(361, 338.5,20,HighCarbssod4 * 10)
  
  //List object: PS 5
  fill(0);
  textSize(7.5);
  text(HighCarbs5, 435, 350);
  
  //Bar:Carbs, PS 5
  strokeWeight(1);
  fill(255,10,10)
  rect(440, 310,20,HighCarbscarbs5)
  
   //Bar:Sodium, PS 5
  strokeWeight(1);
  fill(0,0,255)
  rect(461, 325,20,HighCarbssod5 * 10)
}