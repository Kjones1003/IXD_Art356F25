let monsters = [];
let stars = [];
let selected = null;

function setup() {
  createCanvas(900, 600);
  noStroke();
  textFont("Georgia");

  let url = "https://www.dnd5eapi.co/api/2014/monsters";
  loadJSON(url, gotMonsterList);
}

function gotMonsterList(data) {
  // Load first 40 monsters for variety
  let entries = data.results.slice(0, 40);

  for (let entry of entries) {
    let detailURL = "https://www.dnd5eapi.co" + entry.url;
    loadJSON(detailURL, (monsterData) => {
      monsters.push(monsterData);
      stars.push({
        x: random(width),
        y: random(height),
        r: random(3, 10),
        monster: monsterData,
        baseBright: random(150, 255),
        flicker: random(0.01, 0.05),
        hue: random(360) // each star gets its own color hue
      });
    });
  }
}

function draw() {
  colorMode(HSB, 360, 100, 100, 100);
  background(230, 50, 5, 20);
  noStroke();

  // Draw glowing colorful stars
  for (let s of stars) {
    let bright = s.baseBright + sin(frameCount * s.flicker) * 30;
    fill(s.hue, 80, bright / 3, 100);
    ellipse(s.x, s.y, s.r * 3);
    fill(s.hue, 80, bright, 100);
    ellipse(s.x, s.y, s.r * 1.5);
  }

  // Instructions
  if (!selected) {
    fill(0, 0, 100, 80 + sin(frameCount * 0.05) * 20);
    textAlign(CENTER);
    textSize(22);
    text("Click on a star to see a monster", width / 2, height / 2);
  }

  // Show selected monster
  if (selected) {
    drawMonsterInfo(selected);
  }
}

function mousePressed() {
  for (let s of stars) {
    if (dist(mouseX, mouseY, s.x, s.y) < s.r + 5) {
      selected = s;
      break;
    }
  }
}

function drawMonsterInfo(star) {
  let m = star.monster;

  // Extract AC safely
  let acValue = Array.isArray(m.armor_class)
    ? m.armor_class[0]?.value
    : m.armor_class;

  // Fancy summoning circle
  push();
  translate(star.x, star.y);
  stroke(star.hue, 80, 100);
  noFill();
  strokeWeight(2);
  for (let i = 0; i < 4; i++) {
    ellipse(0, 0, star.r * 15 + sin(frameCount * 0.05 + i) * 10);
  }
  pop();

  // Info box
  push();
  colorMode(RGB);
  fill(0, 180);
  rect(40, height - 170, 280, 130, 15);
  colorMode(HSB, 360, 100, 100, 100);
  fill(star.hue, 80, 100);
  textAlign(LEFT);
  textSize(20);
  textStyle(BOLD);
  text(m.name, 60, height - 140);
  textSize(14);
  fill(0, 0, 100);
  text(
    `Type: ${m.type || "Unknown"}
CR: ${m.challenge_rating || "?"}
HP: ${m.hit_points || "?"}
AC: ${acValue || "?"}
Alignment: ${m.alignment || "?"}`,
    60,
    height - 120
  );
  pop();
}
