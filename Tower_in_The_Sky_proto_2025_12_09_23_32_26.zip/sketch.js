//credit to poised-snow, macrovector,collaborapix, Nataliia_Lehka, stockgiu, FreshPixelReddit, sanctumpixel, Pixeleart Designer, Joanna Kaczmarek, Luz Eugenia Velasquez,WeenterMakesGames, istock, freepik, JWBS_Steam, & Emmett Dahlgren for their art

let player;
let flipped;
let flipped2;
let roomLoaded = false;
let inroom1 = false;
let inroom2 = false;
let inroom3 = false;
let inroom4 = false;
let inroom5 = false;
let inroom6 = false;
let inroom7 = false;
let inroom8 = false;
let inroom9 = false;
let inroom10StoneGolemBoss = false;
let inwinroom = false;
let lastStoneGolemBossAction = 0;
let StoneGolemBossState = "move";
let StoneGolemBossSpeed = 2;

function preload() {
  imgLeft  = loadImage("basicspritebeard1.png");
  imgRight = loadImage("basicspritebeard2.png");
  plyhp = loadImage("borderhp1.png")
  skyb = loadImage("skybackground.jpg")
  imgcrouch = loadImage("Crouch.png")
  imgcrouch2 = loadImage("Crouch2.png")
  strtscrn = loadImage("startscreenNEW.png")
  imgmountbg = loadImage("mountbg.png")
  mground = ("MountGround.png")
  Bgoblin = ("goblinL.png")
  BRgoblin = ("goblinR.png")
  MgoblinL = ("MgoblinL.png")
  MggoblinR = ("MgoblinR.png")
  MWingedgoblinL = ("MWgoblinL.png")
  MWingedgoblinR = ("MWgoblinR.png")
  sky2 = loadImage("CloudyBg-WM.png")
  stoneGolemL = loadImage("StoneGolemL.png");
  stoneGolemR = loadImage("StoneGolemR.png");
  stoneGolemBar = loadImage("WitchMinionhpbar.png")
  wingedgoblinL = loadImage("WgoblinL.png")
  wingedgoblinR = loadImage("WgoblinR.png")
  SwingedgoblinL = loadImage("SWgoblinL.png")
  SwingedgoblinR = loadImage("SWgoblinR.png")
}

function setup() {
  new Canvas(700, 600);
  world.gravity.y = 10;
  projectiles = new Group();
  projectiles.d = 10;
  projectiles.collider = "none";
  
  projectiles2 = new Group();
  projectiles2.d = 10;
  projectiles2.collider = "none";
  
  projectile2 = new Group();
  projectile2.d = 10;
  projectile2.collider = "none";
  
  startButton = new PixelArtButton(295, 300, 150, 50, "START"); //height/2 - 25
  
  startButton2 = new PixelArtButton(280, 360, 150, 50, "RESTART"); //height/2 - 2
}

function draw() {
  
  if (inroom1 == false){background(strtscrn);
  startButton.display();
  
  }
  
  if (inroom1 == true){
  clear(); 
  background(skyb);
  noStroke();
  fill(200, 0, 0);
  rect(5, 25, player.hp, 25);
  fill(0);
  text(player.hp, 40, 26, 100, 25);
  textAlign(LEFT);
  textSize(12);
   image(plyhp, 2, 25); 
    
   if (kb.pressing('left')) {
    player.vel.x = -3;
    player.img = imgLeft;
    flipped=false;
    
  }
  else if (kb.pressing('right')) {
    player.vel.x = 3;
    player.img = imgRight;
    flipped= true;
  }
  else player.vel.x = 0;
    
  if(kb.pressing('shift') && (kb.pressing('right'))){player.vel.x = 6;}
    
  else if(kb.pressing('shift') && (kb.pressing('left'))){player.vel.x = -6;}
    
if (player.vel.y ===0) {
if (kb.presses('up')) {
    player.vel.y = 35;}
  
 player.height = 90;
 player.img.offset.y = 0;
   
 // CROUCHING
if (kb.pressing("down")) {

  player.height = 40;         // crouch height
  player.img.offset.y = 15;   // shift sprite down
  player.img = imgcrouch;
  
  // crouch + move right
  if (kb.pressing("right")) {
    player.vel.x = 3;
    player.img = imgcrouch;   // right-crouch image
  }

  // crouch + move left
  else if (kb.pressing("left")) {
    player.vel.x = -3;
    player.img = imgcrouch2;  // left-crouch image
  }
  else if (!kb.pressing('down') && player.x.vel  == 0){player.image = loadImage("basicspritebeard2.png");}}
}

 if (enemy1.x <= 300){
   enemy1.image = Bgoblin;
   enemy1.img.offset.y = 9;
   enemy1.vel.x = 2.5; //1.5
   
 }
 if (enemy1.x >= 500){
   enemy1.image = BRgoblin;
   enemy1.img.offset.y = 9;
   enemy1.vel.x = -2.5; 
 } 
     
 if (enemyr1e2.y <= 300){
   enemyr1e2.image = wingedgoblinR;
   enemyr1e2.image.scale = 0.3;
   enemyr1e2.img.offset.y = -60;
   enemyr1e2.vel.y = 2.5; //1.5
   
 }
 if (enemyr1e2.y >= 400){
   enemyr1e2.image = wingedgoblinR;
   enemyr1e2.image.scale = 0.3;
   enemyr1e2.img.offset.y = -60;
   enemyr1e2.vel.y = -2.5; 
 } 
  
 if (player.overlaps(enemy1)) player.hp -= 20;
 if (player.overlaps(enemyr1e2)) player.hp -= 20;
  
 if (projectiles.overlaps(enemy1)){
  enemy1.hp -= 1;
  enemy1.image = 'redgoblin.png'
  enemy1.img.offset.y = 9;
}
     
if (projectiles.overlaps(enemyr1e2)){
  enemyr1e2.hp -= 1;
  enemyr1e2.image = 'InjuredWgoblin.png'
  enemyr1e2.image.scale = 0.3;
  enemyr1e2.img.offset.y = -60;
}
  
  if (enemy1.hp <= 0) enemy1.remove();
  if (enemyr1e2.hp <= 0) enemyr1e2.remove();
     
  if (player.hp <= 0){
     tree.remove();
    wallL.remove();
    enemy1.remove();
    player.remove();
    floor1.remove();
    sign.remove();    
    wallR.remove();
    tower.remove();
    TowerintheSky.remove();
    room1();
  }
  
  if (player.overlap(wallR)){
    clear();
    
    TowerintheSky.remove();
    tree.remove();
    wallL.remove();
    enemy1.remove();
    player.remove();
    floor1.remove();
    sign.remove();    
    wallR.remove();
    tower.remove();
    enemyr1e2.remove();
    room2();
  }
}
  
  if (inroom2 == true){clear(); 
  background(skyb);
  noStroke();
  fill(200, 0, 0);
  rect(5, 25, player.hp, 25);
  fill(0);
  text(player.hp, 40, 26, 100, 25);
  textAlign(LEFT);
  textSize(12);
   image(plyhp, 2, 25); 
    
   if (kb.pressing('left')) {
    player.vel.x = -3;
    player.img = imgLeft;
    flipped=false;
    
  }
  else if (kb.pressing('right')) {
    player.vel.x = 3;
    player.img = imgRight;
    flipped= true;
  }
  else player.vel.x = 0;
    
  if(kb.pressing('shift') && (kb.pressing('right'))){player.vel.x = 6;}
    
  else if(kb.pressing('shift') && (kb.pressing('left'))){player.vel.x = -6;}                     
                       
if (player.vel.y === 0) {
if (kb.presses('up')) {
    player.vel.y = 35;}
  
  
  player.height = 90;
 player.img.offset.y = 0;
   
 // CROUCHING
if (kb.pressing("down")) {

  player.height = 40;         // crouch height
  player.img.offset.y = 15;   // shift sprite down
  player.img = imgcrouch;
  
  // crouch + move right
  if (kb.pressing("right")) {
    player.vel.x = 3;
    player.img = imgcrouch;   // right-crouch image
  }

  // crouch + move left
  else if (kb.pressing("left")) {
    player.vel.x = -3;
    player.img = imgcrouch2;  // left-crouch image
  }
  else if (!kb.pressing('down') && player.x.vel  == 0){player.image = loadImage("basicspritebeard2.png");}} 
}
    
                        
    if (enemy2.x <= 220){
   enemy2.image = Bgoblin;
   enemy2.img.offset.y = 9;
   enemy2.vel.x = 2.5; //1.5
   
 }
 if (enemy2.x >= 500){
   enemy2.image = BRgoblin;
   enemy2.img.offset.y = 9;
   enemy2.vel.x = -2.5; 
 } 
  
 if (player.overlaps(enemy2)){ player.hp -= 20;}
  
 if (projectiles.overlaps(enemy2)){
  enemy2.hp -= 1;
  enemy2.image = 'redgoblin.png'
  enemy2.img.offset.y = 9;
}
                        
   if (enemyr2e3.x <= 200){
   enemyr2e3.image = wingedgoblinL;
   enemyr2e3.image.scale = 0.3;
   enemyr2e3.img.offset.y = -60;
   enemyr2e3.vel.x = 3.5;}
                        
   if (enemyr2e3.x >= 500){
   enemyr2e3.image = wingedgoblinR;
   enemyr2e3.image.scale = 0.3;
   enemyr2e3.img.offset.y = -60;
   enemyr2e3.vel.x = -3.5;}
                        
   if (player.overlaps(enemyr2e3)){player.hp -= 20;}
   
   if (enemyr2e3.hp <= 0){ enemyr2e3.remove()}
                        
   if (projectiles.overlaps(enemyr2e3)){
  enemyr2e3.hp -= 1;
  enemyr2e3.image = 'InjuredWgoblin.png'
  enemyr2e3.image.scale = 0.3;
  enemyr2e3.img.offset.y = -60;
}
   
                        
  if (player.hp <= 0){
    clear();
    
    TowerintheSky.remove();
    enemy2.remove();
    enemyr2e3.remove();
    Green.remove();
    tree2.remove();
    tree.remove();
    wallL.remove();
    player.remove();
    floor2.remove();
    sign2.remove();    
    wallR2.remove();
    tower.remove();
    room1()
  }
  
  if (enemy2.hp <= 0) enemy2.remove();
                       
    if (player.overlap(wallR2)){
    clear();
    
    TowerintheSky.remove();
    enemy2.remove();
     enemyr2e3.remove();
    Green.remove();
    tree2.remove();
    tree.remove();
    wallL.remove();
    player.remove();
    floor2.remove();
    sign2.remove();    
    wallR2.remove();
    tower.remove();
    room3();
  }

}
  
  if (inroom3 == true){
  background(skyb);
  noStroke();
  fill(200, 0, 0);
  rect(5, 25, player.hp, 25);
  fill(0);
  text(player.hp, 40, 26, 100, 25);
  textAlign(LEFT);
  textSize(12);
   image(plyhp, 2, 25); 
    
   if (kb.pressing('left')) {
    player.vel.x = -3;
    player.img = imgLeft;
    flipped=false; 
    
  }
  else if (kb.pressing('right')) {
    player.vel.x = 3;
    player.img = imgRight;
    flipped= true;
  }
  else player.vel.x = 0;
    
  if(kb.pressing('shift') && (kb.pressing('right'))){player.vel.x = 6;}
    
  else if(kb.pressing('shift') && (kb.pressing('left'))){player.vel.x = -6;}
    
if (player.vel.y ===0) {
if (kb.presses('up')) {
    player.vel.y = 35;}}
    
  player.height = 90;
 player.img.offset.y = 0;
   
 // CROUCHING
if (kb.pressing("down")) {

  player.height = 40;         // crouch height
  player.img.offset.y = 15;   // shift sprite down
  player.img = imgcrouch;
  
  // crouch + move right
  if (kb.pressing("right")) {
    player.vel.x = 3;
    player.img = imgcrouch;   // right-crouch image
  }

  // crouch + move left
  else if (kb.pressing("left")) {
    player.vel.x = -3;
    player.img = imgcrouch2;  // left-crouch image
  }
  else if (!kb.pressing('down') && player.x.vel  == 0){player.image = loadImage("basicspritebeard2.png");}}
     
      if (enemyr3e1.y <= 390){
   enemyr3e1.image = wingedgoblinR;
   enemyr3e1.image.scale = 0.3;
   enemyr3e1.img.offset.y = -60;
   enemyr3e1.vel.y = 2.5; //1.5
   
 }
 if (enemyr3e1.y >= 500){
   enemyr3e1.image = wingedgoblinR;
   enemyr3e1.image.scale = 0.3;
   enemyr3e1.img.offset.y = -60;
   enemyr3e1.vel.y = -2.5;}
     
 if (player.overlaps(enemyr3e1)) player.hp -= 20;
     
 if (projectiles.overlaps(enemyr3e1)){
  enemyr3e1.hp -= 1;
  enemyr3e1.image = 'InjuredWgoblin.png'
  enemyr3e1.image.scale = 0.3;
  enemyr3e1.img.offset.y = -60;
}
     
 if (enemyr3e1.hp <= 0){enemyr3e1.remove();}
     
 if (enemyr3e2.y <= 390){
   enemyr3e2.image = wingedgoblinR;
   enemyr3e2.image.scale = 0.3;
   enemyr3e2.img.offset.y = -60;
   enemyr3e2.vel.y = 3.5; //1.5
   
 }
 if (enemyr3e2.y >= 500){
   enemyr3e2.image = wingedgoblinR;
   enemyr3e2.image.scale = 0.3;
   enemyr3e2.img.offset.y = -60;
   enemyr3e2.vel.y = -3.5;}
     
 if (player.overlaps(enemyr3e2)) player.hp -= 20;
     
 if (projectiles.overlaps(enemyr3e2)){
  enemyr3e2.hp -= 1;
  enemyr3e2.image = 'InjuredWgoblin.png'
  enemyr3e2.image.scale = 0.3;
  enemyr3e2.img.offset.y = -60;
}
     
 if (enemyr3e2.hp <= 0){enemyr3e2.remove();}
    
 if (player.hp <= 0){
   clear();
   
   TowerintheSky.remove();
   enemyr3e1.remove();
    enemyr3e2.remove();
    tree.remove();
    Green.remove();
    wallL.remove();
    player.remove();
    floor3.remove();
    sign3.remove();    
    mountain.remove();
    room1();
 }
    
 if (player.overlap(mountain)){
    clear();
    
    TowerintheSky.remove();
    enemyr3e1.remove();
    enemyr3e2.remove();
    tree.remove();
    Green.remove();
    wallL.remove();
    player.remove();
    floor3.remove();
    sign3.remove();    
    mountain.remove();
    room4();
  }
     
}
  
  if (inroom4 == true){
   background(imgmountbg);
  noStroke();
  fill(200, 0, 0);
  rect(5, 25, player.hp, 25);
  fill(0);
  text(player.hp, 40, 26, 100, 25);
  textAlign(LEFT);
  textSize(12);
   image(plyhp, 2, 25); 
    
   if (kb.pressing('left')) {
    player.vel.x = -3;
    player.img = imgLeft;
    flipped=false; 
    
  }
  else if (kb.pressing('right')) {
    player.vel.x = 3;
    player.img = imgRight;
    flipped= true;
  }
  else player.vel.x = 0;
    
  if(kb.pressing('shift') && (kb.pressing('right'))){player.vel.x = 6;}
    
  else if(kb.pressing('shift') && (kb.pressing('left'))){player.vel.x = -6;}
    
if (player.vel.y ===0) {
if (kb.presses('up')) {
    player.vel.y = 35;}}
    
   player.height = 90;
 player.img.offset.y = 0;
   
 // CROUCHING
if (kb.pressing("down")) {

  player.height = 40;         // crouch height
  player.img.offset.y = 15;   // shift sprite down
  player.img = imgcrouch;
  
  // crouch + move right
  if (kb.pressing("right")) {
    player.vel.x = 3;
    player.img = imgcrouch;   // right-crouch image
  }

  // crouch + move left
  else if (kb.pressing("left")) {
    player.vel.x = -3;
    player.img = imgcrouch2;  // left-crouch image
  }
  else if (!kb.pressing('down') && player.x.vel  == 0){player.image = loadImage("basicspritebeard2.png");}}
 
  if (enemyr4e1.y <= 390){
   enemyr4e1.image = MWingedgoblinR;
   enemyr4e1.image.scale = 0.3;
   enemyr4e1.img.offset.y = -60;
   enemyr4e1.vel.y = 2.5; //1.5
   
 }
 if (enemyr4e1.y >= 500){
   enemyr4e1.image = MWingedgoblinR;
   enemyr4e1.image.scale = 0.3;
   enemyr4e1.img.offset.y = -60;
   enemyr4e1.vel.y = -2.5;}
     
 if (player.overlaps(enemyr4e1)) player.hp -= 40;
     
 if (projectiles.overlaps(enemyr4e1)){
  enemyr4e1.hp -= 1;
  enemyr4e1.image = 'InjuredWgoblin.png'
  enemyr4e1.image.scale = 0.3;
  enemyr4e1.img.offset.y = -60;
}
     
 if (enemyr4e1.hp <= 0){enemyr4e1.remove();}
    
  if (player.hp <= 0){
    TowerintheSky.remove();
    enemyr4e1.remove();
    boulder.remove();
    Mintsign.remove();
    wallL.remove();
    player.remove();
    floor4.remove();   
    wallR4.remove();
    room4();}
 
 if (player.overlap(wallR4)){
    clear();
    
    TowerintheSky.remove();
    enemyr4e1.remove();
    boulder.remove();
    Mintsign.remove();
    wallL.remove();
    player.remove();
    floor4.remove();   
    wallR4.remove();
    room5();
  }
   
 }  
 
  if (inroom5 == true){
   background(imgmountbg);
  noStroke();
  fill(200, 0, 0);
  rect(5, 25, player.hp, 25);
  fill(0);
  text(player.hp, 40, 26, 100, 25);
  textAlign(LEFT);
  textSize(12);
   image(plyhp, 2, 25); 
    
   if (kb.pressing('left')) {
    player.vel.x = -3;
    player.img = imgLeft;
    flipped=false; 
    
  }
  else if (kb.pressing('right')) {
    player.vel.x = 3;
    player.img = imgRight;
    flipped= true;
  }
  else player.vel.x = 0;
    
  if(kb.pressing('shift') && (kb.pressing('right'))){player.vel.x = 6;}
    
  else if(kb.pressing('shift') && (kb.pressing('left'))){player.vel.x = -6;}
    
if (player.vel.y ===0) {
if (kb.presses('up')) {
    player.vel.y = 35;}}
    
   player.height = 90;
 player.img.offset.y = 0;
   
 // CROUCHING
if (kb.pressing("down")) {

  player.height = 40;         // crouch height
  player.img.offset.y = 15;   // shift sprite down
  player.img = imgcrouch;
  
  // crouch + move right
  if (kb.pressing("right")) {
    player.vel.x = 3;
    player.img = imgcrouch;   // right-crouch image
  }

  // crouch + move left
  else if (kb.pressing("left")) {
    player.vel.x = -3;
    player.img = imgcrouch2;  // left-crouch image
  }
  else if (!kb.pressing('down') && player.x.vel  == 0){player.image = loadImage("basicspritebeard2.png");}}
    
    if (vulture.x <= 160){vulture.vel.x = 3.5; vulture.image = "Vulture.png"; vulture.image.scale = 0.5;}
    if (vulture.x >= 700){vulture.vel.x = -3.5; vulture.image = "VultureR.png"; vulture.image.scale = 0.5;}
    
    
 if (player.overlap(wallR5)){
    clear();
    
    vulture.remove();
    CloudSign.remove();
    wallL.remove();
    player.remove();
    floor5.remove();   
    wallR5.remove();
    room6();
  }
   
 }
  
  if (inroom6 == true){
   background(imgmountbg);
  noStroke();
  fill(200, 0, 0);
  rect(5, 25, player.hp, 25);
  fill(0);
  text(player.hp, 40, 26, 100, 25);
  textAlign(LEFT);
  textSize(12);
   image(plyhp, 2, 25); 
    
   if (kb.pressing('left')) {
    player.vel.x = -3;
    player.img = imgLeft;
    flipped=false; 
    
  }
  else if (kb.pressing('right')) {
    player.vel.x = 3;
    player.img = imgRight;
    flipped= true;
  }
  else player.vel.x = 0;
    
  if(kb.pressing('shift') && (kb.pressing('right'))){player.vel.x = 6;}
    
  else if(kb.pressing('shift') && (kb.pressing('left'))){player.vel.x = -6;}
    
if (player.vel.y ===0) {
if (kb.presses('up')) {
    player.vel.y = 35;}}
    
   player.height = 90;
 player.img.offset.y = 0;
   
 // CROUCHING
if (kb.pressing("down")) {

  player.height = 40;         // crouch height
  player.img.offset.y = 15;   // shift sprite down
  player.img = imgcrouch;
  
  // crouch + move right
  if (kb.pressing("right")) {
    player.vel.x = 3;
    player.img = imgcrouch;   // right-crouch image
  }

  // crouch + move left
  else if (kb.pressing("left")) {
    player.vel.x = -3;
    player.img = imgcrouch2;  // left-crouch image
  }
  else if (!kb.pressing('down') && player.x.vel  == 0){player.image = loadImage("basicspritebeard2.png");}}
    
   if (elevator.y <= 260){elevator.x = 190; elevator.y = 540;}
   elevator.vel.y = -1.5;
   elevator.vel.x = 0;
    
   if (enemyr6e1.y <= 190){
   enemyr6e1.image = MWingedgoblinR;
   enemyr6e1.image.scale = 0.3;
   enemyr6e1.img.offset.y = -60;
   enemyr6e1.vel.y = 2.5; //1.5
   
 }
 if (enemyr6e1.y >= 500){
   enemyr6e1.image = MWingedgoblinR;
   enemyr6e1.image.scale = 0.3;
   enemyr6e1.img.offset.y = -60;
   enemyr6e1.vel.y = -2.5;}
     
 if (player.overlaps(enemyr6e1)) player.hp -= 40;
     
 if (projectiles.overlaps(enemyr6e1)){
  enemyr6e1.hp -= 1;
  enemyr6e1.image = 'InjuredWgoblin.png'
  enemyr6e1.image.scale = 0.3;
  enemyr6e1.img.offset.y = -60;
}
     
 if (enemyr6e1.hp <= 0){enemyr6e1.remove();} 
   
 if (player.hp <= 0){
   elevator.remove();
    Stalagbottom.remove();
    Stalagtop.remove();
    wallL.remove();
    player.remove();
    floor6.remove();   
    wallR6.remove();
    instructSign.remove();
    enemyr6e1.remove();
    room4();
 }
   
 if (player.overlap(wallR6)){
    clear();
    
    elevator.remove();
    Stalagbottom.remove();
    Stalagtop.remove();
    wallL.remove();
    player.remove();
    floor6.remove();   
    wallR6.remove();
    instructSign.remove();
    enemyr6e1.remove();
    room7();
  }
   
 }
  
  if (inroom7 == true){
  background(imgmountbg);
  noStroke();
  textAlign(LEFT);
  fill(200, 0, 0);
  rect(5, 25, player.hp, 25);
  fill(0);
  text(player.hp, 40, 26, 100, 25);
  
  textSize(12);
   image(plyhp, 2, 25); 
    
   if (kb.pressing('left')) {
    player.vel.x = -3;
    player.img = imgLeft;
    flipped=false; 
    
  }
  else if (kb.pressing('right')) {
    player.vel.x = 3;
    player.img = imgRight;
    flipped= true;
  }
  else player.vel.x = 0;
    
  if(kb.pressing('shift') && (kb.pressing('right'))){player.vel.x = 6;}
    
  else if(kb.pressing('shift') && (kb.pressing('left'))){player.vel.x = -6;}
    
if (player.vel.y ===0) {
if (kb.presses('up')) {
    player.vel.y = 35;}}
    
 player.height = 90;
 player.img.offset.y = 0;
   
 // CROUCHING
if (kb.pressing("down")) {

  player.height = 40;         // crouch height
  player.img.offset.y = 15;   // shift sprite down
  player.img = imgcrouch;
  
  // crouch + move right
  if (kb.pressing("right")) {
    player.vel.x = 3;
    player.img = imgcrouch;   // right-crouch image
  }

  // crouch + move left
  else if (kb.pressing("left")) {
    player.vel.x = -3;
    player.img = imgcrouch2;  // left-crouch image
  }
  else if (!kb.pressing('down') && player.x.vel  == 0 ){player.image = loadImage("basicspritebeard2.png");}}
    
     if (enemyr7e1.y <= 190){
   enemyr7e1.image = MWingedgoblinR;
   enemyr7e1.image.scale = 0.3;
   enemyr7e1.img.offset.y = -60;
   enemyr7e1.vel.y = 2.5; //1.5
   
 }
 if (enemyr7e1.y >= 500){
   enemyr7e1.image = MWingedgoblinR;
   enemyr7e1.image.scale = 0.3;
   enemyr7e1.img.offset.y = -60;
   enemyr7e1.vel.y = -2.5;}
     
 if (player.overlaps(enemyr7e1)) player.hp -= 40;
     
 if (projectiles.overlaps(enemyr7e1)){
  enemyr7e1.hp -= 1;
  enemyr7e1.image = 'InjuredWgoblin.png'
  enemyr7e1.image.scale = 0.3;
  enemyr7e1.img.offset.y = -60;
}
     
 if (enemyr7e1.hp <= 0){enemyr7e1.remove();}
    
  if (enemyr7e2.y <= 190){
   enemyr7e2.image = MWingedgoblinR;
   enemyr7e2.image.scale = 0.3;
   enemyr7e2.img.offset.y = -60;
   enemyr7e2.vel.y = 2.5; //1.5
   
 }
 if (enemyr7e2.y >= 400){
   enemyr7e2.image = MWingedgoblinR;
   enemyr7e2.image.scale = 0.3;
   enemyr7e2.img.offset.y = -60;
   enemyr7e2.vel.y = -2.5;}
     
 if (player.overlaps(enemyr7e2)) player.hp -= 40;
     
 if (projectiles.overlaps(enemyr7e2)){
  enemyr7e2.hp -= 1;
  enemyr7e2.image = 'InjuredWgoblin.png'
  enemyr7e2.image.scale = 0.3;
  enemyr7e2.img.offset.y = -60;
}
     
 if (enemyr7e2.hp <= 0){enemyr7e2.remove();}
    
 if (player.hp <= 0){
   floor7b.remove();
    Dsign.remove();
    skyfloor.remove();
    skyfloor1.remove();
    skyfloor2.remove();
    player.remove();
    floor7.remove();   
    wallR7.remove();
   wallL.remove();
   enemyr7e1.remove();
   enemyr7e2.remove();
    room4();
 }
   
if (player.y >= 1000){
    clear();
  
    floor7.remove();
    skyfloor.remove();
    skyfloor1.remove();
    skyfloor2.remove();
    floor7b.remove();
    wallR7.remove();
    Dsign.remove();
    wallL.remove();
    enemyr7e1.remove();
    enemyr7e2.remove();
    clear();
    clear();
    clear();
    inroom5 = false;
    inroom6 = false;
    inroom7 = false;
    inroom8 = false;
    inroom1 = true;
    room7();
}
    
 if (player.overlap(wallR7)){
    clear();
    
    floor7b.remove();
    Dsign.remove();
    skyfloor.remove();
    skyfloor1.remove();
    skyfloor2.remove();
    player.remove();
    floor7.remove();   
    wallR7.remove();
   wallL.remove();
   enemyr7e1.remove();
   enemyr7e2.remove();
    room8();
  }
}
  
  if (inroom8 == true){
  background(sky2);
  noStroke();
  textAlign(LEFT);
  fill(200, 0, 0);
  rect(5, 25, player.hp, 25);
  fill(0);
  text(player.hp, 40, 26, 100, 25);
  
  textSize(12);
   image(plyhp, 2, 25); 
    
   if (kb.pressing('left')) {
    player.vel.x = -3;
    player.img = imgLeft;
    flipped=false; 
    
  }
  else if (kb.pressing('right')) {
    player.vel.x = 3;
    player.img = imgRight;
    flipped= true;
  }
  else player.vel.x = 0;
    
  if(kb.pressing('shift') && (kb.pressing('right'))){player.vel.x = 6;}
    
  else if(kb.pressing('shift') && (kb.pressing('left'))){player.vel.x = -6;}
    
if (player.vel.y ===0) {
if (kb.presses('up')) {
    player.vel.y = 35;}}
    
 player.height = 90;
 player.img.offset.y = 0;
   
 // CROUCHING
if (kb.pressing("down")) {

  player.height = 40;         // crouch height
  player.img.offset.y = 15;   // shift sprite down
  player.img = imgcrouch;
  
  // crouch + move right
  if (kb.pressing("right")) {
    player.vel.x = 3;
    player.img = imgcrouch;   // right-crouch image
  }

  // crouch + move left
  else if (kb.pressing("left")) {
    player.vel.x = -3;
    player.img = imgcrouch2;  // left-crouch image
  }
  else if (!kb.pressing('down') && player.x.vel  == 0 ){player.image = loadImage("basicspritebeard2.png");}}
  
    floor8c.vel.y = -2
    floor8c.vel.x = 0
    if (floor8c.y <= 200){floor8c.x = 110; floor8c.y = 600;}
    
    if (enemyr8e1.y <= 190){
   enemyr8e1.image = SwingedgoblinL;
   enemyr8e1.image.scale = 0.3;
   enemyr8e1.img.offset.y = -60;
   enemyr8e1.vel.y = 2.5; //1.5
   
 }
 if (enemyr8e1.y >= 500){
   enemyr8e1.image = SwingedgoblinL;
   enemyr8e1.image.scale = 0.3;
   enemyr8e1.img.offset.y = -60;
   enemyr8e1.vel.y = -2.5;}
     
 if (player.overlaps(enemyr8e1)) player.hp -= 60;
     
 if (projectiles.overlaps(enemyr8e1)){
  enemyr8e1.hp -= 1;
  enemyr8e1.image = 'InjuredWgoblinL.png'
  enemyr8e1.image.scale = 0.3;
  enemyr8e1.img.offset.y = -60;
}
     
 if (enemyr8e1.hp <= 0){enemyr8e1.remove();}
    
 if (player.hp <= 0){
    enemyr8e1.remove();
    player.remove();
    floor8.remove();
    floor8b.remove();
    floor8c.remove();
    floor8d.remove();
    floor8e.remove();
    wallR8.remove();
    WarningSign1.remove();
    WarningSign2.remove();
    wallL.remove();
    room8();
 }
    
    
if (player.y >= 1000){
  clear();
   
    player.remove();
    floor8.remove();
    floor8b.remove();
    floor8c.remove();
    floor8d.remove();
    floor8e.remove();
    wallR8.remove();
    wallL.remove();
    enemyr8e1.remove();
    WarningSign1.remove();
    WarningSign2.remove();
    
    background(skyb);
    inroom5 = false;
    inroom6 = false;
    inroom7 = false;
    inroom8 = false;
    inroom1 = true;
    room7();
}
    
 if (player.overlap(wallR8)){
    clear();
    
    enemyr8e1.remove();
    player.remove();
    floor8.remove();
    floor8b.remove();
    floor8c.remove();
    floor8d.remove();
    floor8e.remove();
    wallR8.remove();
    wallR8b.remove();
    WarningSign1.remove();
    WarningSign2.remove();
    wallL8.remove();
    room9();
  }
}
  
  if (inroom9 == true){
  background(sky2);
  noStroke();
  textAlign(LEFT);
  fill(200, 0, 0);
  rect(5, 25, player.hp, 25);
  fill(0);
  text(player.hp, 40, 26, 100, 25);
  
  textSize(12);
   image(plyhp, 2, 25); 
    
   if (kb.pressing('left')) {
    player.vel.x = -3;
    player.img = imgLeft;
    flipped=false; 
    
  }
  else if (kb.pressing('right')) {
    player.vel.x = 3;
    player.img = imgRight;
    flipped= true;
  }
  else player.vel.x = 0;
    
  if(kb.pressing('shift') && (kb.pressing('right'))){player.vel.x = 6;}
    
  else if(kb.pressing('shift') && (kb.pressing('left'))){player.vel.x = -6;}
    
if (player.vel.y ===0) {
if (kb.presses('up')) {
    player.vel.y = 35;}}
    
 player.height = 90;
 player.img.offset.y = 0;
   
 // CROUCHING
if (kb.pressing("down")) {

  player.height = 40;         // crouch height
  player.img.offset.y = 15;   // shift sprite down
  player.img = imgcrouch;
  
  // crouch + move right
  if (kb.pressing("right")) {
    player.vel.x = 3;
    player.img = imgcrouch;   // right-crouch image
  }

  // crouch + move left
  else if (kb.pressing("left")) {
    player.vel.x = -3;
    player.img = imgcrouch2;  // left-crouch image
  }
  else if (!kb.pressing('down') && player.x.vel  == 0 ){player.image = loadImage("basicspritebeard2.png");}}
  
    floor9b.vel.y = -2
    floor9b.vel.x = 0
    if (floor9b.y <= 200){floor9b.x = 110; floor9b.y = 600;}
    
    floor9c.vel.y = -2
    floor9c.vel.x = 0
    if (floor9c.y <= 200){floor9c.x = 610; floor9c.y = 600;}
    
    
if ((player.y >= 1000)){
    clear();
    inroom9 =false;
    floor9c.remove();
    floor9d.remove();
    player.remove();
    floor9.remove();
    floor9b.remove();
    CloudDoor.remove();
    background(skyb);
    wallR9.remove();
    wallL9.remove();
    room7();
}
    
 if (player.overlap(CloudDoor)){
    clear();
   
    CloudDoor.remove();
    player.remove();
    floor9.remove();
    floor9b.remove();
    floor9c.remove();
    floor9d.remove();
    room10StoneGolemBoss();
    wallR9.remove();
    wallL9.remove();
  }
}
  
  if (inroom10StoneGolemBoss == true){
  textSize(12);
  background(sky2);
  noStroke();
  textAlign(LEFT);
  fill(200, 0, 0);
  rect(5, 25, player.hp, 25);
  fill(0);
  text(player.hp, 40, 26, 100, 25);

   image(plyhp, 2, 25); 
    
   if (kb.pressing('left')) {
    player.vel.x = -3;
    player.img = imgLeft;
    flipped=false; 
    
  }
  else if (kb.pressing('right')) {
    player.vel.x = 3;
    player.img = imgRight;
    flipped= true;
  }
  else player.vel.x = 0;
    
  if(kb.pressing('shift') && (kb.pressing('right'))){player.vel.x = 6;}
    
  else if(kb.pressing('shift') && (kb.pressing('left'))){player.vel.x = -6;}
    
    
if (player.vel.y <= 0) {
if (kb.presses('up')) {
    player.vel.y = 35;}}
    
 player.height = 90;
 player.img.offset.y = 0;
   
 // CROUCHING
if (kb.pressing("down")) {

  player.height = 40;         // crouch height
  player.img.offset.y = 15;   // shift sprite down
  player.img = imgcrouch;
  
  // crouch + move right
  if (kb.pressing("right")) {
    player.vel.x = 3;
    player.img = imgcrouch;   // right-crouch image
  }

  // crouch + move left
  else if (kb.pressing("left")) {
    player.vel.x = -3;
    player.img = imgcrouch2;  // left-crouch image
  }
  else if (!kb.pressing('down') && player.x.vel  == 0 ){player.image = loadImage("basicspritebeard2.png");}}
  
    floor10b.vel.y = -2
    floor10b.vel.x = 0
    if (floor10b.y <= 200){floor10b.x = 225; floor10b.y = 550;}
    
    floor10c.vel.y = -2
    floor10c.vel.x = 0
    if (floor10c.y <= 200){floor10c.x = 525; floor10c.y = 550;}
    
    
if ((player.y >= 1000)){
  clear();
    
    inroom10StoneGolemBoss =false;
    player.remove();
    floor10.remove();
    floor10b.remove();
    floor10c.remove();
    miniplatform1L.remove();
    miniplatform2L.remove();
    miniplatform1R.remove();
    miniplatform2R.remove();
    StoneGolemBoss.remove();
    miniplatform3RM.remove();
  
    room1();
}
    
    // StoneGolemBoss AI state machine
  if (StoneGolemBossState === "move") {
    StoneGolemBossMovement();
  } else if (StoneGolemBossState === "shoot") {
    StoneGolemBossShootState();
  }
    
    if(projectiles.overlaps(StoneGolemBoss)){StoneGolemBoss.hp -= 20;}
    
    if(projectiles2.overlaps(player)){player.hp -= 10;}
    
    if (player.overlap(StoneGolemBoss)){player.hp -= 50}
  
  
  textAlign(LEFT);
  fill(200, 0, 0);
  rect(290, 25, StoneGolemBoss.hp, 25);
  fill(0);
  text(StoneGolemBoss.hp, 490, 25, 100, 25);
  image(stoneGolemBar, 290.5, 25);
    
    if (player.hp <= 0){
    player.remove();
    floor10.remove();
    floor10b.remove();
    floor10c.remove();
    miniplatform1L.remove();
    miniplatform2L.remove();
    miniplatform3LM.remove();
    miniplatform1R.remove();
    miniplatform2R.remove();
    StoneGolemBoss.remove();
    miniplatform3RM.remove();
    TowerintheSky.remove();
    wallR10.remove();
    wallL10.remove();
    room10StoneGolemBoss();
    StoneGolemBoss.hp = 400;
    }
    
    
    
 if (StoneGolemBoss.hp <= 0){
    clear();
   
    wallR10.remove();
    wallL10.remove();   
    TowerintheSky.remove();
    player.remove();
    floor10.remove();
    floor10b.remove();
    floor10c.remove();
    miniplatform1L.remove();
    miniplatform2L.remove();
    miniplatform3LM.remove();
    miniplatform1R.remove();
    miniplatform2R.remove();
    StoneGolemBoss.remove();
    miniplatform3RM.remove();
    endingWOO();
  }
}
  
  if (inwinroom == true){
     gamestarted = false;
  background(220)
  fill(0);
  textSize(25);
  textAlign(CENTER);
  text("The Wizard made it back to his tower", 360, 220)
  text("and destroyed all of the Witch's guardians!", 360, 290)
  text("You Win!", 410, 340)
  //startButton2.display();
  }
}

//wizard firing Projectile
function keyPressed() {
  if (kb.pressing("space")) {
    let projectile = new projectiles.Sprite();
    projectile.image = 'blastpsrite.png';
    if (flipped) {projectile.image = 'blastpsrite2.png';}
    projectile.x = player.x;
    projectile.y = player.y;

    let direction = createVector(mouse.x - player.x);
    if (flipped) {
      projectile.vel.x = 5;
    } else {
      projectile.vel.x = -5;
    }
  }
}

//start button
class PixelArtButton {
  constructor(x, y, w, h, label) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.label = label;
    this.isHovered = false;
  }

  // Start Button
  checkClick() {
    if (mouseX > this.x && mouseX < this.x + this.w && mouseY > this.y && mouseY < this.y + this.h) {
      this.isHovered = true;
      
    } else {
      this.isHovered = false;
    }
  }

  // Button Style
  display(){
    this.checkClick();

    if (this.isHovered) {
      fill(255, 0, 0); 
    } else {
      fill(200, 0, 0); 
    }
    
    stroke(0);
    strokeWeight(6); 
    rect(this.x, this.y, this.w, this.h, 8); 
    noStroke();
    
    fill(255);
    textSize(20);
    textAlign(CENTER, CENTER);
    text(this.label, this.x + this.w / 2, this.y + this.h / 2);
  }
}

function startGame(){
   if (!roomLoaded) {
    roomLoaded = true;
    room1();}
}

function RestartGame(){
    clear();
    inroom10StoneGolemBoss = false;
    inwinroom = false;
    inroom1 = true;
    background(skyb);
    room1();
}

function endingWOO(){
  clear();
  inroom10StoneGolemBoss = false;
  inwinroom = true;
  
}

function room1(){
  let inroom2 = false;
  let inroom3 = false;
  let inroom4 = false;
  let inroom5 = false;
  let inroom6 = false;
  let inroom7 = false;
  let inroom8 = false;
  let inroom9 = false;
  inroom1 = true;
  clear();
  
  background(skyb);
  
  tower = new Sprite();
  tower.x = 10;
  tower.y = 445;
  tower.width = 50;
  tower.height = 50;
  tower.image = "Tower.png"
  tower.collider = "none";
  tower.image.scale = 2.1;
  
  tree = new Sprite();
  tree.x = 350
  tree.y = 495
  tree.height = 50;
  tree.width = 50;
  tree.image = "Tree.png";
  tree.collider = "none";
  tree.image.scale = 0.5;
  //tree.debug = true;
  tree.image.offset.y = -250;
  tree.image.offset.x = -20;
  
  enemy1 = new Sprite();
  enemy1.img = 'goblinL.png';
  //enemy1.debug = true;
  enemy1.x = 300; //280 //122
  enemy1.y = 490;
  enemy1.width = 42;
  enemy1.height = 59;
  enemy1.image.offset.y = 3;
  enemy1.collider = 'kinematic';
  enemy1.img.offset.y = 9;
  enemy1.hp = 3;
  
  enemyr1e2 = new Sprite();
  enemyr1e2.img = 'WgoblinR.png';
  //enemyr1e2.debug = true;
  enemyr1e2.x = 550; //280 //122
  enemyr1e2.y = 400;
  enemyr1e2.width = 42;
  enemyr1e2.height = 59;
  enemyr1e2.image.offset.y = 3;
  enemyr1e2.image.scale = 0.3;
  enemyr1e2.collider = 'kinematic';
  enemyr1e2.img.offset.y = 9;
  enemyr1e2.hp = 3;
  
  floor1 = new Sprite();
  floor1.y = 550;
  floor1.x = 350;
  floor1.w = width;
  floor1.h = 48;
  floor1.collider = 'static';
  floor1.img = "Grassground.png"
  //floor1.debug = true;
  floor1.img.scale = 0.15;
  floor1.img.offset.y = 70;
            
  player = new Sprite();
  player.width = 40;
  player.height = 90;
  player.x = 95;
  player.y = 470;
  player.image = loadImage("basicspritebeard2.png");
  player.rotationLock = true;
  player.collider = "dynamic";
  player.hp = 100;
  player.vel.y = 0;
  
  sign = new Sprite();
  sign.y = 550;
  sign.x = 570;
  sign.img = "Signage.png";
  sign.width = 50;
  sign.height = 50;
  sign.collider = "none";
  
  wallR = new Sprite();
  wallR.x = 700;
  wallR.y =  200;
  wallR.image = "nothing.png";
  wallR.width = 5;
  wallR.height = 700;
  wallR.collider = 'static';
  
  wallL = new Sprite();
  wallL.x = 0;
  wallL.y =  300;
  wallL.image = "nothing.png";
  wallL.width = 5;
  wallL.height = 600;
  wallL.collider = 'static';
  
  TowerintheSky = new Sprite();
  TowerintheSky.y = 70;
  TowerintheSky.x = 600;
  TowerintheSky.img = "Tower_in_the_skyHQ.png";
  TowerintheSky.width = 50;
  TowerintheSky.height = 50;
  TowerintheSky.collider = "none";
  TowerintheSky.img.scale = 0.15;
  
}

function room2(){
  let inroom1 = false;
  inroom2 = true;
  clear();
  
  background(skyb);
  
  player.vel.y = 0;
  tree = new Sprite();
  tree.x = 150
  tree.y = 495
  tree.height = 50;
  tree.width = 50;
  tree.image = "Tree.png";
  tree.collider = "none";
  tree.image.scale = 0.5;
  //tree.debug = true;
  tree.image.offset.y = -250;
  tree.image.offset.x = -20;
  
  Green = new Sprite();
  Green.x = 350;
  Green.y = 485;
  Green.width = 50;
  Green.height = 50;
  Green.image = "ActualBush.png";
  Green.collider = "none";
  Green.image.scale = 0.2;
  Green.image.offset.y = -5;
  
  tree2 = new Sprite();
  tree2.x = 550
  tree2.y = 495
  tree2.height = 50;
  tree2.width = 50;
  tree2.image = "OthaTree2.png";
  tree2.collider = "none";
  tree2.image.scale = 0.5;
  //tree2.debug = true;
  tree2.image.offset.y = -250;
  tree2.image.offset.x = -20;

  floor2 = new Sprite();
  floor2.y = 550;
  floor2.x = 350;
  floor2.w = width;
  floor2.h = 48;
  floor2.collider = 'static';
  floor2.img = "Grassground.png"
  //floor2.debug = true;
  floor2.img.scale = 0.15;
  floor2.img.offset.y = 70;
            
  player = new Sprite();
  player.width = 40;
  player.height = 90;
  player.x = 50;
  player.y = 470;
  player.image = loadImage("basicspritebeard2.png");
  player.rotationLock = true;
  player.collider = "dynamic";
  player.hp = 100;
  player.vel.y = 0;
  
  sign2 = new Sprite();
  sign2.y = 550;
  sign2.x = 570;
  sign2.img = "Signage2.png";
  sign2.width = 50;
  sign2.height = 50;
  sign2.collider = "none";
  
  wallR2 = new Sprite();
  wallR2.x = 700;
  wallR2.y =  200;
  wallR2.image = "nothing.png";
  wallR2.width = 5;
  wallR2.height = 700;
  wallR2.collider = 'static';
  
  wallL = new Sprite();
  wallL.x = 0;
  wallL.y =  300;
  wallL.image = "nothing.png";
  wallL.width = 5;
  wallL.height = 600;
  wallL.collider = 'static';
  
  enemy2 = new Sprite();
  enemy2.img = 'goblinL.png';
  //enemy2.debug = true;
  enemy2.x =220; //280 //122
  enemy2.y = 490;
  enemy2.width = 42;
  enemy2.height = 59;
  enemy2.image.offset.y = 3;
  enemy2.collider = 'kinematic';
  enemy2.img.offset.y = 9;
  enemy2.hp = 3;
  
  enemyr2e3 = new Sprite();
  enemyr2e3.img = 'WgoblinR.png';
  //enemyr2e3.debug = true;
  enemyr2e3.x = 200; //280 //122
  enemyr2e3.y = 430;
  enemyr2e3.width = 42;
  enemyr2e3.height = 59;
  enemyr2e3.image.offset.y = 3;
  enemyr2e3.image.scale = 0.3;
  enemyr2e3.collider = 'kinematic';
  enemyr2e3.img.offset.y = 9;
  enemyr2e3.hp = 3;
  
  TowerintheSky = new Sprite();
  TowerintheSky.y = 70;
  TowerintheSky.x = 600;
  TowerintheSky.img = "Tower_in_the_skyHQ.png";
  TowerintheSky.width = 50;
  TowerintheSky.height = 50;
  TowerintheSky.collider = "none";
  TowerintheSky.img.scale = 0.15;
  
}

function room3(){
  let inroom1 = false;
  let inroom2 = false;
  inroom3 = true;
  clear();
  
  background(skyb);
  
  tree = new Sprite();
  tree.x = 180
  tree.y = 495
  tree.height = 50;
  tree.width = 50;
  tree.image = "Tree.png";
  tree.collider = "none";
  tree.image.scale = 0.5;
  //tree.debug = true;
  tree.image.offset.y = -250;
  tree.image.offset.x = -20;
  
  Green = new Sprite();
  Green.x = 380;
  Green.y = 485;
  Green.width = 50;
  Green.height = 50;
  Green.image = "ActualBush.png";
  Green.collider = "none";
  Green.image.scale = 0.2;
  Green.image.offset.y = -5;
  
  mountain = new Sprite();
  mountain.x = 700;
  mountain.y =  450;
  mountain.image = "Mountain.png";
  mountain.width = 5;
  mountain.height = 700;
  mountain.collider = 'static';
  //mountain.debug = true;
  
  wallL = new Sprite();
  wallL.x = 0;
  wallL.y =  300;
  wallL.image = "nothing.png";
  wallL.width = 5;
  wallL.height = 600;
  wallL.collider = 'static';
  
  floor3 = new Sprite();
  floor3.y = 550;
  floor3.x = 350;
  floor3.w = width;
  floor3.h = 48;
  floor3.collider = 'static';
  floor3.img = "Grassground.png"
  //floor3.debug = true;
  floor3.img.scale = 0.15;
  floor3.img.offset.y = 70;
            
  player = new Sprite();
  player.width = 40;
  player.height = 90;
  player.x = 50;
  player.y = 470;
  player.image = loadImage("basicspritebeard2.png");
  player.rotationLock = true;
  player.collider = "dynamic";
  player.hp = 100;
  player.vel.y = 0;
  
  sign3 = new Sprite();
  sign3.y = 550;
  sign3.x = 570;
  sign3.img = "Signage4.png";
  sign3.width = 50;
  sign3.height = 50;
  sign3.collider = "none";
  sign3.img.scale = 0.9;
  
  enemyr3e1 = new Sprite();
  enemyr3e1.img = 'WgoblinR.png';
  //enemyr3e1.debug = true;
  enemyr3e1.x = 350; //280 //122
  enemyr3e1.y = 390;
  enemyr3e1.width = 42;
  enemyr3e1.height = 59;
  enemyr3e1.image.offset.y = 3;
  enemyr3e1.image.scale = 0.3;
  enemyr3e1.collider = 'kinematic';
  enemyr3e1.img.offset.y = 9;
  enemyr3e1.hp = 3;
  
  enemyr3e2 = new Sprite();
  enemyr3e2.img = 'WgoblinR.png';
  //enemyr3e2.debug = true;
  enemyr3e2.x = 550; //280 //122
  enemyr3e2.y = 390;
  enemyr3e2.width = 42;
  enemyr3e2.height = 59;
  enemyr3e2.image.offset.y = 3;
  enemyr3e2.image.scale = 0.3;
  enemyr3e2.collider = 'kinematic';
  enemyr3e2.img.offset.y = 9;
  enemyr3e2.hp = 3;
  
  TowerintheSky = new Sprite();
  TowerintheSky.y = 70;
  TowerintheSky.x = 600;
  TowerintheSky.img = "Tower_in_the_skyHQ.png";
  TowerintheSky.width = 50;
  TowerintheSky.height = 50;
  TowerintheSky.collider = "none";
  TowerintheSky.img.scale = 0.15;
}

//mountain start
function room4(){
  let inroom1 = false;
  let inroom2 = false;
  let inroom3 = false;
  inroom4 = true;
  clear();
  
  background(imgmountbg);
  
  boulder = new Sprite();
  boulder.x = 450;
  boulder.y = 485;
  boulder.width = 50;
  boulder.height = 50;
  boulder.image = "Iraack.png";
  boulder.collider = "none";
  boulder.image.scale = 0.55;
  
  floor4 = new Sprite();
  floor4.y = 550;
  floor4.x = 350;
  floor4.w = width;
  floor4.h = 48;
  floor4.collider = 'static';
  floor4.img = mground
  //floor4.debug = true;
  //floor4.img.scale = ;
  floor4.img.offset.y = 33;
            
  player = new Sprite();
  player.width = 40;
  player.height = 90;
  player.x = 50;
  player.y = 470;
  player.image = loadImage("basicspritebeard2.png");
  player.rotationLock = true;
  player.collider = "dynamic";
  player.hp = 100;
  player.vel.y = 0;
  
  wallR4 = new Sprite();
  wallR4.x = 700;
  wallR4.y =  200;
  wallR4.image = "nothing.png";
  wallR4.width = 5;
  wallR4.height = 700;
  wallR4.collider = 'static';
  
  wallL = new Sprite();
  wallL.x = 0;
  wallL.y =  300;
  wallL.image = "nothing.png";
  wallL.width = 5;
  wallL.height = 600;
  wallL.collider = 'static';
  
  Mintsign = new Sprite();
  Mintsign.y = 590;
  Mintsign.x = 200;
  Mintsign.img = "MountIntSignage.png";
  Mintsign.width = 50;
  Mintsign.height = 50;
  Mintsign.collider = "none";
  Mintsign.img.scale = 0.45;
  
  enemyr4e1 = new Sprite();
  enemyr4e1.img = 'MWgoblinR.png';
  //enemyr4e1.debug = true;
  enemyr4e1.x = 350; //280 //122
  enemyr4e1.y = 390;
  enemyr4e1.width = 42;
  enemyr4e1.height = 59;
  enemyr4e1.image.offset.y = 3;
  enemyr4e1.image.scale = 0.3;
  enemyr4e1.collider = 'kinematic';
  enemyr4e1.img.offset.y = 9;
  enemyr4e1.hp = 6;
  
  TowerintheSky = new Sprite();
  TowerintheSky.y = 100;
  TowerintheSky.x = 550;
  TowerintheSky.img = "Tower_in_the_skyHQ.png";
  TowerintheSky.width = 50;
  TowerintheSky.height = 50;
  TowerintheSky.collider = "none";
  TowerintheSky.img.scale = 0.25;
}

//Vulture Room
function room5(){
  let inroom1 = false;
  let inroom2 = false;
  let inroom3 = false;
  let inroom4 = false;
  inroom5 = true;
  clear();
  
  background(imgmountbg);
  
  vulture = new Sprite();
  vulture.x = 160;
  vulture.y = 50;
  vulture.width = 50;
  vulture.height = 50;
  vulture.image = "Vulture.png"
  vulture.collider = "nothing"; //30 - 700
  vulture.image.scale = 0.5;
  
  floor5 = new Sprite();
  floor5.y = 550;
  floor5.x = 350;
  floor5.w = width;
  floor5.h = 48;
  floor5.collider = 'static';
  floor5.img = mground
  //floor5.debug = true;
  //floor5.img.scale = ;
  floor5.img.offset.y = 33;
            
  player = new Sprite();
  player.width = 40;
  player.height = 90;
  player.x = 50;
  player.y = 470;
  player.image = loadImage("basicspritebeard2.png");
  player.rotationLock = true;
  player.collider = "dynamic";
  player.hp = 100;
  player.vel.y = 0;
  
  wallR5 = new Sprite();
  wallR5.x = 700;
  wallR5.y =  200;
  wallR5.image = "nothing.png";
  wallR5.width = 5;
  wallR5.height = 700;
  wallR5.collider = 'static';
  
  wallL = new Sprite();
  wallL.x = 0;
  wallL.y =  300;
  wallL.image = "nothing.png";
  wallL.width = 5;
  wallL.height = 600;
  wallL.collider = 'static';
  
  CloudSign = new Sprite();
  CloudSign.y = 550;
  CloudSign.x = 570;
  CloudSign.img = "CloudSignage.png";
  CloudSign.width = 50;
  CloudSign.height = 50;
  CloudSign.collider = "none";
  CloudSign.img.scale = 0.45;
}

//mountain challenge
function room6(){
  let inroom1 = false;
  let inroom2 = false;
  let inroom3 = false;
  let inroom4 = false;
  let inroom5 = false;
  inroom6 = true;
  clear();

  background(imgmountbg);
  
  floor6 = new Sprite();
  floor6.y = 550;
  floor6.x = 350;
  floor6.w = width;
  floor6.h = 48;
  floor6.collider = 'static';
  floor6.img = mground
  //floor6.debug = true;
  //floor6.img.scale = ;
  floor6.img.offset.y = 33;
            
  player = new Sprite();
  player.width = 40;
  player.height = 90;
  player.x = 20;
  player.y = 470;
  player.image = loadImage("basicspritebeard2.png");
  player.rotationLock = true;
  player.collider = "dynamic";
  player.hp = 100;
  player.vel.y = 0;
  
  wallR6 = new Sprite();
  wallR6.x = 700;
  wallR6.y =  200;
  wallR6.image = "nothing.png";
  wallR6.width = 5;
  wallR6.height = 700;
  wallR6.collider = 'static';
  
  wallL = new Sprite();
  wallL.x = 0;
  wallL.y =  300;
  wallL.image = "nothing.png";
  wallL.width = 5;
  wallL.height = 600;
  wallL.collider = 'static';
  
  Stalagtop = new Sprite();
  Stalagtop.x = 450;
  Stalagtop.y =  200;
  Stalagtop.image = "CeilinHanger.png";
  Stalagtop.width = 10;
  Stalagtop.height = 550;
  Stalagtop.collider = 'static';
  //Stalagtop.debug = true;
  Stalagtop.image.scale = 1.1
  Stalagtop.image.offset.x = 10;
  Stalagtop.image.offset.y = 30;
  
  elevator = new Sprite();
  elevator.x = 190; 
  elevator.y = 540; 
  elevator.width=120;
  elevator.height= 20;
  elevator.color = " red";
  elevator.collider = "kinematic";
  elevator.rotationLock = true;
  elevator.immovable = true;
  
  Stalagbottom = new Sprite();
  Stalagbottom.x = 230;
  Stalagbottom.y =  430;
  Stalagbottom.image = "Stalagbottom.png";
  Stalagbottom.width = 10;
  Stalagbottom.height = 300;
  Stalagbottom.collider = 'static';
  //Stalagbottom.debug = true;
  Stalagbottom.image.scale = 0.85
  Stalagbottom.image.offset.x = 30;
  Stalagbottom.image.offset.y = 32;
  
  instructSign = new Sprite();
  instructSign.y = 590;
  instructSign.x = 290;
  instructSign.img = "instructSign.png";
  instructSign.width = 50;
  instructSign.height = 50;
  instructSign.collider = "none";
  instructSign.img.scale = 0.35;
  
  enemyr6e1 = new Sprite();
  enemyr6e1.img = 'MWgoblinR.png';
  //enemyr6e1.debug = true;
  enemyr6e1.x = 350; //280 //122
  enemyr6e1.y = 190;
  enemyr6e1.width = 42;
  enemyr6e1.height = 59;
  enemyr6e1.image.offset.y = 3;
  enemyr6e1.image.scale = 0.3;
  enemyr6e1.collider = 'kinematic';
  enemyr6e1.img.offset.y = 9;
  enemyr6e1.hp = 6;
}

//mountain peak to cloud
function room7(){
  
  let inroom1 = false;
  let inroom2 = false;
  let inroom3 = false;
  let inroom4 = false;
  let inroom5 = false;
  let inroom6 = false;
  inroom7 = true;
  clear();
  
  background(imgmountbg);
  
  floor7 = new Sprite();
  floor7.y = 500;
  floor7.x = 350;
  floor7.w = 200;
  floor7.h = 48;
  floor7.collider = 'static';
  floor7.image = "Mountain.png";
  //floor7.debug = true;
  
  floor7b = new Sprite();
  floor7b.y = 550;
  floor7b.x = 100;
  floor7b.w = 300;
  floor7b.h = 48;
  floor7b.collider = 'static';
  //floor7b.debug = true;
  floor7b.image = "MountainStump.png";
  
  skyfloor= new Sprite();
  skyfloor.y = 400;
  skyfloor.x = 450;
  skyfloor.w = 100;
  skyfloor.h = 18;
  skyfloor.collider = 'static';
  skyfloor.image = "purpCldpltfrm.png";
  skyfloor.image.scale = 0.57;
  //skyfloor.debug = true;
  
  skyfloor1= new Sprite();
  skyfloor1.y = 330;
  skyfloor1.x = 570;
  skyfloor1.w = 100;
  skyfloor1.h = 18;
  skyfloor1.collider = 'static';
  skyfloor1.image = "purpCldpltfrm.png";
  skyfloor1.image.scale = 0.57;
  //skyfloor1.debug = true;
  
  skyfloor2= new Sprite();
  skyfloor2.y = 250;
  skyfloor2.x = 670;
  skyfloor2.w = 100;
  skyfloor2.h = 18;
  skyfloor2.collider = 'static';
  skyfloor2.image = "purpCldpltfrm.png";
  skyfloor2.image.scale = 0.57;
  //skyfloor2.debug = true;
            
  player = new Sprite();
  player.width = 40;
  player.height = 90;
  player.x = 50;
  player.y = 455;
  player.image = loadImage("basicspritebeard2.png");
  player.rotationLock = true;
  player.collider = "dynamic";
  player.hp = 100;
 //player.debug = true;
  player.vel.y = 0;
  
  wallR7 = new Sprite();
  wallR7.x = 700;
  wallR7.y =  115
  wallR7.image = "nothing.png";
  wallR7.width = 10;
  wallR7.height = 250;
  wallR7.collider = 'static';
  
  wallL = new Sprite();
  wallL.x = 0;
  wallL.y =  300;
  wallL.image = "nothing.png";
  wallL.width = 5;
  wallL.height = 600;
  wallL.collider = 'static';
  
  Dsign = new Sprite();
  Dsign.y = 570;
  Dsign.x = 520;
  Dsign.img = "DeathSignage.png";
  Dsign.width = 50;
  Dsign.height = 50;
  Dsign.collider = "none";
  Dsign.img.scale = 0.3;
  
  enemyr7e1 = new Sprite();
  enemyr7e1.img = 'MWgoblinR.png';
  //enemyr7e1.debug = true;
  enemyr7e1.x = 250; //280 //122
  enemyr7e1.y = 190;
  enemyr7e1.width = 42;
  enemyr7e1.height = 59;
  enemyr7e1.image.offset.y = 3;
  enemyr7e1.image.scale = 0.3;
  enemyr7e1.collider = 'kinematic';
  enemyr7e1.img.offset.y = 9;
  enemyr7e1.hp = 3;
  
  enemyr7e2 = new Sprite();
  enemyr7e2.img = 'MWgoblinR.png';
  //enemyr7e2.debug = true;
  enemyr7e2.x = 550; //280 //122
  enemyr7e2.y = 190;
  enemyr7e2.width = 42;
  enemyr7e2.height = 59;
  enemyr7e2.image.offset.y = 3;
  enemyr7e2.image.scale = 0.3;
  enemyr7e2.collider = 'kinematic';
  enemyr7e2.img.offset.y = 9;
  enemyr7e2.hp = 3;
}

//cloud
function room8(){
  let inroom1 = false;
  let inroom2 = false;
  let inroom3 = false;
  let inroom4 = false;
  let inroom5 = false;
  let inroom6 = false;
  let inroom7 = false;
  inroom8 = true;
  clear();
  
  player = new Sprite();
  player.width = 40;
  player.height = 90;
  player.x = 600;
  player.y = 555;
  player.image = loadImage("basicspritebeard1.png");
  player.rotationLock = true;
  player.collider = "dynamic";
  player.hp = 100;
  player.vel.y = 0;
 //player.debug = true;
  
  floor8 = new Sprite();
  floor8.y = 590;
  floor8.x = 585;
  floor8.w = 900;
  floor8.h = 20;
  floor8.collider = 'static';
  floor8.image = "CloudlongOUT1.png";
  //floor8.debug = true;
  floor8.image.scale = 0.3;
  floor8.image.offset.x = 8;
  floor8.image.offset.y = -100;
  
  floor8b = new Sprite();
  floor8b.y = 485;
  floor8b.x = 420;
  floor8b.w = 225;
  floor8b.h = 7;
  floor8b.collider = 'static';
  floor8b.image = "CloudlongOUT1.png";
  //floor8b.debug = true;
  floor8b.image.scale = 0.3;
  floor8b.image.offset.x = 8;
  floor8b.image.offset.y = -100;
  
  floor8c = new Sprite();
  floor8c.y = 395;
  floor8c.x = 110;
  floor8c.w = 225;
  floor8c.h = 20;
  floor8c.collider = 'kinematic';
  floor8c.image = "CloudlongOUT1.png";
  //floor8c.debug = true;
  floor8c.image.scale = 0.3;
  floor8c.image.offset.x = 8;
  floor8c.image.offset.y = -100;
  floor8c.rotationLock = true;
  
  floor8d = new Sprite();
  floor8d.y = 200;
  floor8d.x = 360;
  floor8d.w = 245;
  floor8d.h = 10;
  floor8d.collider = 'static';
  floor8d.image = "CloudDoubleOUT.png";
  //floor8d.debug = true;
  floor8d.image.scale = 0.3;
  floor8d.image.offset.x = 4;
  floor8d.image.offset.y = -50;
  
  floor8e = new Sprite();
  floor8e.y = 110;
  floor8e.x = 680;
  floor8e.w = 245;
  floor8e.h = 10;
  floor8e.collider = 'static';
  floor8e.image = "CloudBigOUT.png";
  //floor8e.debug = true;
  floor8e.image.scale = 0.3;
  floor8e.image.offset.x = 4;
  floor8e.image.offset.y = -50;
  
  wallL8 = new Sprite();
  wallL8.x = 0;
  wallL8.y =  300;
  wallL8.image = "nothing.png";
  wallL8.width = 5;
  wallL8.height = 600;
  wallL8.collider = 'static';
  //wallL8.debug = true;
  
  wallR8 = new Sprite();
  wallR8.x = 705;
  wallR8.y =  55
  wallR8.image = "nothing.png";
  wallR8.width = 10;
  wallR8.height = 150;
  wallR8.collider = 'static';
  //wallR8.debug = true;
  
  wallR8b = new Sprite();
  wallR8b.x = 700;
  wallR8b.y =  450;
  wallR8b.image = "nothing.png";
  wallR8b.width = 5;
  wallR8b.height = 600;
  wallR8b.collider = 'static';
  //wallR8b.debug = true;
  
  WarningSign1 = new Sprite();
  WarningSign1.y = 590;
  WarningSign1.x = 200;
  WarningSign1.img = "Warning1Sign.png";
  WarningSign1.width = 50;
  WarningSign1.height = 50;
  WarningSign1.collider = "none";
  WarningSign1.img.scale = 0.35;
  
  WarningSign2 = new Sprite();
  WarningSign2.y = 590;
  WarningSign2.x = 450;
  WarningSign2.img = "Warning2Sign.png";
  WarningSign2.width = 50;
  WarningSign2.height = 50;
  WarningSign2.collider = "none";
  WarningSign2.img.scale = 0.33;
  
  enemyr8e1 = new Sprite();
  enemyr8e1.img = "SWgoblinL.png";
  //enemyr8e1.debug = true;
  enemyr8e1.x = 350; //280 //122
  enemyr8e1.y = 190;
  enemyr8e1.width = 42;
  enemyr8e1.height = 59;
  enemyr8e1.image.offset.y = 3;
  enemyr8e1.image.scale = 0.3;
  enemyr8e1.collider = 'kinematic';
  enemyr8e1.img.offset.y = 9;
  enemyr8e1.hp = 3;
  
  
}

//cloud
function room9(){
  let inroom1 = false;
  let inroom2 = false;
  let inroom3 = false;
  let inroom4 = false;
  let inroom5 = false;
  let inroom6 = false;
  let inroom7 = false;
  let inroom8 = false;
  inroom9 = true;
  clear();
  
  CloudDoor = new Sprite();
  CloudDoor.y = 159;
  CloudDoor.x = 360;
  CloudDoor.img = "Cloudydoor.png";
  CloudDoor.width = 50;
  CloudDoor.height = 75;
  CloudDoor.collider = "kinematic";
  CloudDoor.image.offset.y = -10;
  //CloudDoor.debug = true;
  
  player = new Sprite();
  player.width = 40;
  player.height = 90;
  player.x = 360;
  player.y = 555;
  player.image = loadImage("basicspritebeard1.png");
  player.rotationLock = true;
  player.collider = "dynamic";
  player.hp = 100;
 //player.debug = true;
  player.vel.y = 0;
  
  floor9 = new Sprite();
  floor9.y = 590;
  floor9.x = 360;
  floor9.w = 800;
  floor9.h = 20;
  floor9.collider = 'static';
  floor9.image = "CloudlongOUT1.png";
  //floor9.debug = true;
  floor9.image.scale = 0.3;
  floor9.image.offset.x = 8;
  floor9.image.offset.y = -100;
  
  floor9b = new Sprite();
  floor9b.y = 395;
  floor9b.x = 110;
  floor9b.w = 225;
  floor9b.h = 20;
  floor9b.collider = 'kinematic';
  floor9b.image = "CloudlongOUT1.png";
  //floor9b.debug = true;
  floor9b.image.scale = 0.3;
  floor9b.image.offset.x = 8;
  floor9b.image.offset.y = -100;
  floor9b.rotationLock = true;
  floor9b.immovable = true;
  
  floor9c = new Sprite();
  floor9c.y = 395;
  floor9c.x = 610;
  floor9c.w = 225;
  floor9c.h = 20;
  floor9c.collider = 'kinematic';
  floor9c.image = "CloudlongOUT1.png";
  //floor9c.debug = true;
  floor9c.image.scale = 0.3;
  floor9c.image.offset.x = 8;
  floor9c.image.offset.y = -100;
  floor9c.rotationLock = true;
  floor9c.immovable = true;
  
  floor9d = new Sprite();
  floor9d.y = 230;
  floor9d.x = 360;
  floor9d.w = 225;
  floor9d.h = 20;
  floor9d.collider = 'static';
  floor9d.image = "CloudlongOUT1.png";
  //floor9d.debug = true;
  floor9d.image.scale = 0.3;
  floor9d.image.offset.x = 8;
  floor9d.image.offset.y = -100;
  
  wallL9 = new Sprite();
  wallL9.x = 0;
  wallL9.y =  300;
  wallL9.image = "nothing.png";
  wallL9.width = 5;
  wallL9.height = 600;
  wallL9.collider = 'static';
  //wallL9.debug = true;
  
  wallR9 = new Sprite();
  wallR9.x = 700;
  wallR9.y =  300;
  wallR9.image = "nothing.png";
  wallR9.width = 5;
  wallR9.height = 600;
  wallR9.collider = 'static';
  //wallR.debug = true;
}

//cloud
function room10StoneGolemBoss(){
  let inroom1 = false;
  let inroom2 = false;
  let inroom3 = false;
  let inroom4 = false;
  let inroom5 = false;
  let inroom6 = false;
  let inroom7 = false;
  let inroom8 = false;
  let inroom9 = false;
  inroom10StoneGolemBoss = true;
  clear();
  
  TowerintheSky = new Sprite();
  TowerintheSky.y = 300;
  TowerintheSky.x = 360;
  TowerintheSky.img = "Tower_in_the_skyHQ.png";
  TowerintheSky.width = 50;
  TowerintheSky.height = 50;
  TowerintheSky.collider = "none";
  TowerintheSky.img.scale = 1;
  
  floor10 = new Sprite();
  floor10.y = 590;
  floor10.x = 360;
  floor10.w = 1000;
  floor10.h = 20;
  floor10.collider = 'static';
  floor10.image = "CloudFloor.png";
  //floor10.debug = true;
  floor10.image.scale = 0.899;
  floor10.image.offset.x = 2;
  floor10.image.offset.y = -40;
  
  player = new Sprite();
  player.width = 40;
  player.height = 90;
  player.x = 125;
  player.y = 200;
  player.image = loadImage("basicspritebeard2.png");
  player.rotationLock = true;
  player.collider = "dynamic";
  player.hp = 100;
 //player.debug = true;
  player.vel.y = 0;
  
  floor10b = new Sprite();
  floor10b.y = 395;
  floor10b.x = 225;
  floor10b.w = 112.5;
  floor10b.h = 10;
  floor10b.collider = 'kinematic';
  floor10b.image = "CloudlongOUT1.png";
  //floor10b.debug = true;
  floor10b.image.scale = 0.17;
  floor10b.image.offset.x = 8;
  floor10b.image.offset.y = -50;
  floor10b.rotationLock = true;
  floor10b.immovable = true;
  
  floor10c = new Sprite();
  floor10c.y = 395;
  floor10c.x = 525;
  floor10c.w = 112.5;
  floor10c.h = 20;
  floor10c.collider = 'kinematic';
  floor10c.image = "CloudlongOUT1.png";
  //floor10c.debug = true;
  floor10c.image.scale = 0.17;
  floor10c.image.offset.x = 8;
  floor10c.image.offset.y = -40;
  floor10c.rotationLock = true;
  floor10c.immovable = true;
  
  miniplatform1L = new Sprite();
  miniplatform1L.y = 210;
  miniplatform1L.x = 125;
  miniplatform1L.w = 56.25;
  miniplatform1L.h = 20;
  miniplatform1L.collider = 'static';
  miniplatform1L.color = "darkred"
  //miniplatform1L.debug = true;
  
  miniplatform2L = new Sprite();
  miniplatform2L.y = 470;
  miniplatform2L.x = 75;
  miniplatform2L.w = 56.25;
  miniplatform2L.h = 20;
  miniplatform2L.collider = 'static';
  miniplatform2L.color = "darkred"
  
  miniplatform3LM = new Sprite();
  miniplatform3LM.y = 330;
  miniplatform3LM.x = 100;
  miniplatform3LM.w = 56.25;
  miniplatform3LM.h = 20;
  miniplatform3LM.collider = 'static';
  miniplatform3LM.color = "darkred"
  
  miniplatform1R = new Sprite();
  miniplatform1R.y = 220;
  miniplatform1R.x = 635;
  miniplatform1R.w = 100; //56.25
  miniplatform1R.h = 20;
  miniplatform1R.collider = 'static';
  miniplatform1R.color = "darkred"
  //miniplatform1R.debug = true;
  
  miniplatform3RM = new Sprite();
  miniplatform3RM.y = 340;
  miniplatform3RM.x = 350;
  miniplatform3RM.w = 56.25;
  miniplatform3RM.h = 20;
  miniplatform3RM.collider = 'static';
  miniplatform3RM.color = "darkred"
  
  miniplatform2R = new Sprite();
  miniplatform2R.y = 470;
  miniplatform2R.x = 635;
  miniplatform2R.w = 56.25;
  miniplatform2R.h = 20;
  miniplatform2R.collider = 'static';
  miniplatform2R.color = "darkred"
  
  StoneGolemBoss = new Sprite();
  StoneGolemBoss.x = 360; 
  StoneGolemBoss.y = 500;
  StoneGolemBoss.height = 300;
  StoneGolemBoss.width = 200;
  StoneGolemBoss.image = stoneGolemL;
  StoneGolemBoss.collider = "kinematic";
  StoneGolemBoss.vel.x = 2;
  //StoneGolemBoss.debug = true;
  StoneGolemBoss.hp = 400;
  
  
 wallL10 = new Sprite();
  wallL10.x = -100;
  wallL10.y =  300;
  wallL10.image = "nothing.png";
  wallL10.width = 5;
  wallL10.height = 600;
  wallL10.collider = 'static';
  wallL10.debug = true;
 
 wallR10 = new Sprite();
  wallR10.x = 800;
  wallR10.y =  300;
  wallR10.image = "nothing.png";
  wallR10.width = 5;
  wallR10.height = 600;
  wallR10.collider = 'static';
  //wallR.debug = true;
}

function StoneGolemBossMovement() {

  // Base platform width = 800, centered at x=360
  // So edges are: -40 and 760
  if (StoneGolemBoss.x >= 760) {
    StoneGolemBoss.vel.x = -StoneGolemBossSpeed;
    flipped2 = false;    
    StoneGolemBoss.image = stoneGolemR;// face left
  }
  if (StoneGolemBoss.x <= -40) {
    StoneGolemBoss.vel.x = StoneGolemBossSpeed;
    flipped2 = true;
    StoneGolemBoss.image = stoneGolemL;// face right
  }

  // Random chance to shoot every few seconds
  if (millis() - lastStoneGolemBossAction > 2000) {    // check every 2 sec
    if (random() < 0.02) {                   // 2% chance
      StoneGolemBoss.vel.x = 0;                        // stop moving
      StoneGolemBossState = "shoot";                   // switch state
      lastStoneGolemBossAction = millis();
    }
  }
}

function StoneGolemBossShootState() {

  // Delay before firing (dramatic pause)
  if (millis() - lastStoneGolemBossAction > 300) {

    fireStoneGolemBossProjectile();   // <--- your projectile system

    // After shooting, resume movement
    StoneGolemBoss.vel.x = flipped ? StoneGolemBossSpeed : -StoneGolemBossSpeed;
    StoneGolemBossState = "move";
    lastStoneGolemBossAction = millis();
  }
}

function fireStoneGolemBossProjectile() {

  // number of bullets + spread angle
  let bulletCount = 3;
  let spreadAngle = 100; // degrees between bullets

  // Base direction (straight at the player)
  let baseDir = createVector(player.x - StoneGolemBoss.x, player.y - StoneGolemBoss.y);
  baseDir = baseDir.normalize();

  // FIRE BULLETS
  for (let i = 0; i < bulletCount; i++) {

    // spread angles: -1, 0, +1 → left, center, right
    let angleOffset = (i - 1) * spreadAngle;
    let shotDir = baseDir.copy().rotate(radians(angleOffset));
    shotDir.setMag(5); // bullet speed

    let projectile3 = new projectiles2.Sprite();

    // choose image based on StoneGolemBoss facing direction
    projectile3.image = 'Rockblastsprite3.png';
    if (flipped) {
      projectile3.image = 'Rockblastsprite4.png';
    }

    // spawn at StoneGolemBoss
    projectile3.x = StoneGolemBoss.x;
    projectile3.y = StoneGolemBoss.y;

    // velocity using spread direction
    projectile3.vel.x = shotDir.x;
    projectile3.vel.y = shotDir.y;

    projectile3.life = 200;
  }
}

function mousePressed() {

  if (startButton.isHovered) {
    startGame();
  }

  if (startButton2.isHovered) {
    
    
    RestartGame();
  }
}